## ProbabilityWorks

ProbabilityWorks is a Python Package that simplifies important statistical analysis functions for users.

### Install
`pip install ProbabiliyWorks`

### Classes

`GivenProbability`

#### Attrib

|Name   |Description   |
|-------|--------------|

#### Methods

|Name   |Description   |
|-------|--------------|



`ProbabilityDensity`